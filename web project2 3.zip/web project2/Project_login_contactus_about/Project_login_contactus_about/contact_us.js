const formHeading = document.querySelector(".form-heading");
const formInputs = document.querySelectorAll(".contact-form-input");

formInputs.forEach((input)=>{
    var placeholder = input.placeholder;
    input.addEventListener("focus",()=>{
        formHeading.style.opacity = "0";
        console.log("PPPP",)
        setTimeout(()=>{
            formHeading.textContent = 'Your' +' '+ placeholder;
            formHeading.style.opacity = "1";
        },300);
    });
});