const deleteIcons = document.querySelectorAll(".delete-icon");

deleteIcons.forEach(function(icon) {
  icon.addEventListener("click", function() {
    const confirmed = confirm("Are you sure you want to delete this row?");
    if (confirmed) {
      const row = icon.parentNode.parentNode;
      row.classList.add("removed");
      setTimeout(function() {
        row.parentNode.removeChild(row);
      }, 500);
    }
  });
});