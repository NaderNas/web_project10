/**$(document).ready(function(){
  $(".pro").slice(0,4).fadeIn();
  $(".seeMoreBtn").click(function(){
    $(".pro").slice(0,12).fadeIn();
    $(this).fadeOut();
  });
});**/
$(document).ready(function() {
  const defaultCount = 4;
  const images = $(".pro");
  let shownCount = defaultCount;


  images.slice(0, shownCount).slideDown(1000);

  $("#seeMoreBtn").click(function() {
    shownCount += defaultCount;
    images.slice(0, shownCount).show();
    if (shownCount >= images.length) {
      $("#seeMoreBtn").hide();
      
    }
  });
});