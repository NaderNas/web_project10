
//this prouduct
var MainImg = document.getElementById("MainImg");
var smallimg = document.getElementsByClassName("small-img");

smallimg[0].onclick = function(){
  MainImg.src = smallimg[0].src;
}
smallimg[1].onclick = function(){
  MainImg.src = smallimg[1].src;
}
smallimg[2].onclick = function(){
  MainImg.src = smallimg[2].src;
}
smallimg[3].onclick = function(){
  MainImg.src = smallimg[3].src;
}


const sizeSelect = document.getElementById("size-select");

sizeSelect.addEventListener("change", function() {
  const selectedSize = sizeSelect.value;
  console.log("Selected size:", selectedSize);
});


const quantityInput = document.getElementById("quantity");
quantityInput.value = "1";


/*$(document).ready(function() {
  const slideWidth = $(".slide").width();
  let currentPosition = 0;

  $("#next-button").click(function() {
    if (currentPosition > -slideWidth * 3) {
      currentPosition -= slideWidth;
      $("#slider").animate({ left: currentPosition + "px" }, 500);
    }
  });

  $("#prev-button").click(function() {
    if (currentPosition < 0) {
      currentPosition += slideWidth;
      $("#slider").animate({ left: currentPosition + "px" }, 500);
    }
  });
});**/

//cart

